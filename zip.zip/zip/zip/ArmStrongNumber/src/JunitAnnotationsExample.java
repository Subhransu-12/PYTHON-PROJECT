
public class JunitAnnotationsExample {

}
