import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)

@SuiteClasses ( {ArmstrongNumber.class, ArmstrongNumber1.class, ArmstrongNumber2.class, ArmstrongNumber3.class,
		ArmstrongNumber4.class , ArmstrongNumber5.class , ArmstrongNumber6.class} )
public class TestSuiteExample {

}
