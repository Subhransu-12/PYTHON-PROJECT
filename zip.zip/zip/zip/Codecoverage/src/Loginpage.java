public class Loginpage {

    public String login(String username, String password) {
        if (username.equals("Administrator") && password.matches("([0-9])([a-zA-Z])")) {
            return "Login successful";
        } else {
            return "Invalid credentials";
        }
    }
}
