import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class Loginpagetest {

    @Test
    public void testValidLogin() {
        Loginpage loginpage = new Loginpage();
        String result = loginpage.login("Administrator", "1aBcDeFg");
        assertEquals("Invalid credentials",result);
    }

    @Test
    public void testInvalidUsername() {
        Loginpage loginpage = new Loginpage();
        String result = loginpage.login("NotAdmin", "1aBcDeFg");
        assertEquals("Invalid credentials",result);
    }

    @Test
    public void testInvalidPassword() {
        Loginpage loginpage = new Loginpage();
        String result = loginpage.login("Administrator", "12345678");
        assertEquals("Invalid credentials", result);
    }
}
