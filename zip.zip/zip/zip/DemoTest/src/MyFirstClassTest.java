import org.junit.Test;

public class MyFirstClassTest {
@Test
public void myFirstMethod() {
}
}