import org.junit.Test;

public class MySecondClassTest {
@Test
public void mySecondMethod() {
	
}
}
