public class LoginPage {
	    private String username;
	    private String password;

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }

	    public boolean isValid() {
	        if (username == null || username.isEmpty()) {
	            return false;
	        }
	        if (password == null || password.isEmpty()) {
	            return false;
	        }
	        if (username.matches("^[0-9!@#$%^&*(),.?\":{}|<> ]")) {
	            return false;
	        }
	        if (password.length() < 8) {
	            return false;
	        }
	        if (!password.matches(".*[!@#$%^&*(),.?\":{}|<> ].*")) {
	            return false;
	        }
	        if (!password.matches(".*\\d.*")) {
	            return false;
	        }
	        return true;
	    }
	}
