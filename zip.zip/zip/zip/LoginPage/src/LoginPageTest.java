import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class LoginPageTest {
	@Before
	@Test
	  public void testValidCredentials() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("valid_username");
	    loginPage.setPassword("valid_password1$");
	    assertTrue(loginPage.isValid());
	  }

	  @Test
	  public void testUsernameStartingWithUnderscore() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("_valid_username");
	    loginPage.setPassword("valid_password1$");
	    assertTrue(loginPage.isValid());
	  }

	  
	  @Test
	  public void testUsernameStartingWithInvalidCharacter() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("$invalid_username");
	    loginPage.setPassword("valid_password1$");
	    assertTrue(loginPage.isValid());
	  }

	  @Test
	  public void testUsernameBlank() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("");
	    loginPage.setPassword("valid_password1$");
	    assertFalse(loginPage.isValid());
	  }

	  @After
	  @Test
	  public void testPasswordBlank() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("valid_username");
	    loginPage.setPassword("");
	    assertFalse(loginPage.isValid());
	  }

	  @Test
	  public void testPasswordLengthLessThan8() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("valid_username");
	    loginPage.setPassword("pass1$");
	    assertFalse(loginPage.isValid());
	  }

	  @Ignore
	  @Test
	  public void testPasswordWithoutSpecialSymbol() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("valid_username");
	    loginPage.setPassword("valid_password1");
	    assertFalse(loginPage.isValid());
	  }

	  @Test
	  public void testPasswordWithoutNumeric() {
	    LoginPage loginPage = new LoginPage();
	    loginPage.setUsername("valid_username");
	    loginPage.setPassword("valid_password$");
	    assertFalse(loginPage.isValid());
	  }

}
