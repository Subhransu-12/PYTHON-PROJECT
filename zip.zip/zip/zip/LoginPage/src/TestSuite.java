import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
	@SuiteClasses({LoginPage.class, LoginPageTest.class})
	public class TestSuite {

}
