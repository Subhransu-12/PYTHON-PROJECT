public class PrimeNo {
	public boolean prime(int x) {
        boolean flag = true;
        if(x < 1000 || x > 1999) {
            flag = false;
        }
        else {
            for(int i = 2; i <= x / 2; i++) {
                if(x % i == 0) {
                    flag = false;
                    break;
                }
            }
        }
        return flag;
    }
}