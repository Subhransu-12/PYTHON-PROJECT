import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PrimeNoTest {
    @Test
    public void testPrime() {
        PrimeNo primeNum = new PrimeNo();
        assertEquals(true, primeNum.prime(1009));
        assertEquals(false, primeNum.prime(1000));
        assertEquals(false, primeNum.prime(999));
        assertEquals(false, primeNum.prime(2000));
    }
}