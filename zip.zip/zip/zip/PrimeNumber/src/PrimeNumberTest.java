import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
	public class PrimeNumberTest {
	    private int inputNumber;
	    private boolean expectedResult;

	    public PrimeNumberTest(int inputNumber, boolean expectedResult) {
	        this.inputNumber = inputNumber;
	        this.expectedResult = expectedResult;
	    }

	    public boolean isPrime(int number) {
	        if (number <= 1) {
	            return false;
	        }
	        for (int i = 2; i <= Math.sqrt(number); i++) {
	            if (number % i == 0) {
	                return false;
	            }
	        }
	        return true;
	    }

	    @Parameters
	    public static Collection<Object[]> primeNumbers() {
	        return Arrays.asList(new Object[][] {
	                { 2, true },
	                { 3, true },
	                { 4, false },
	                { 5, true },
	                { 6, false },
	                { 7, true },
	                { 8, false }
	        });
	    }

	    @Test
	    public void testIsPrime() {
	        assertEquals(expectedResult, isPrime(inputNumber));
	    }
}
