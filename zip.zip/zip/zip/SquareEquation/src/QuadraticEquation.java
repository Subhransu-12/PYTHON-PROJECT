public class QuadraticEquation {
		public boolean hasRealRoots(double a, double b, double c) {
			double discriminant = b * b - 4 * a * c;
			return discriminant >= 0 && a != 0;
		}
}
