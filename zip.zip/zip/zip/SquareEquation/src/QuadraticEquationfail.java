import static org.junit.Assert.assertFalse;

import org.junit.Test;

public class QuadraticEquationfail {
	@Test
	public void testImaginaryRoots1() {
	QuadraticEquation q = new QuadraticEquation();
	assertFalse(q.hasRealRoots(3, 2, 5));
	}

	@Test
	public void testImaginaryRoots2() {
	QuadraticEquation q = new QuadraticEquation();
	assertFalse(q.hasRealRoots(1, 1, 1));
	}

	@Test
	public void testImaginaryRoots3() {
	QuadraticEquation q = new QuadraticEquation();
	assertFalse(q.hasRealRoots(2, 4, 6));
	}

}
