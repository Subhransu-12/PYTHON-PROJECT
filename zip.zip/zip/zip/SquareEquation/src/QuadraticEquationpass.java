import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class QuadraticEquationpass {
		@Test
		public void testRealRoots1() {
		QuadraticEquation q = new QuadraticEquation();
		assertTrue(q.hasRealRoots(4, 4, 1));
		}

		@Test
		public void testRealRoots2() {
		QuadraticEquation q = new QuadraticEquation();
		assertTrue(q.hasRealRoots(2, -7, 3));
		}

		@Test
		public void testRealRoots3() {
		QuadraticEquation q = new QuadraticEquation();
		assertTrue(q.hasRealRoots(-5, -4, 1));
		}

		@Test
		public void testRealRoots4() {
		QuadraticEquation q = new QuadraticEquation();
		assertTrue(q.hasRealRoots(1, -6, 8));
		}

		@Test
		public void testRealRoots5() {
		QuadraticEquation q = new QuadraticEquation();
		assertTrue(q.hasRealRoots(-2, 3, 0));
		}

}
