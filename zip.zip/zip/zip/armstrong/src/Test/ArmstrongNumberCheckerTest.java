package Test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ArmstrongNumberCheckerTest {
	@Test
    public void testIsArmstrongNumber1() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(153);
        assertEquals(true, result);
    }
    
    @Test
    public void testIsArmstrongNumber2() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(370);
        assertEquals(true, result);
    }
    
    @Test
    public void testIsArmstrongNumber3() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(371);
        assertEquals(true, result);
    }
    
    @Test
    public void testIsArmstrongNumber4() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(407);
        assertEquals(true, result);
    }
    
    @Test
    public void testIsArmstrongNumberFail1() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(99);
        assertEquals(false, result);
    }
    
    @Test
    public void testIsArmstrongNumberFail2() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(500);
        assertEquals(false, result);
    }
    
    @Test
    public void testIsArmstrongNumberFail3() {
        ArmstrongNumberChecker checker = new ArmstrongNumberChecker();
        boolean result = checker.isArmstrongNumber(800);
        assertEquals(false, result);
    }
}
