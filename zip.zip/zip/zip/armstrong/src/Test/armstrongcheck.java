package Test;

public class armstrongcheck {

}
