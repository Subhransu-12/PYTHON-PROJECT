package com.lpu.helloworld.demo_maventest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AppTest {
    @Test
    public void testPrime() {
        App primeNum = new App();
        assertEquals(true, primeNum.prime(1009));
        assertEquals(false, primeNum.prime(1000));
        assertEquals(false, primeNum.prime(999));
        assertEquals(false, primeNum.prime(2000));
    }
}